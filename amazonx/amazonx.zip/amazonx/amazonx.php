<?php
/*
Plugin Name: Amazon Express
Plugin URI: http://www.rampantlogic.com/amazonx
Description: Loads Amazon product images and Amazon Associates referral links into posts from the ISBN/ASIN. Includes a one to five star rating system and shortcode to list all posts within a specified range of ratings.
Version: 1.2
Author: Rampant Logic
Author URI: http://www.rampantlogic.com
*/

require_once('amazonx-box.php');
require_once('amazonx-table.php');

function amazonx_save_metabox_data($post_id) {
  // verify this came from the our screen and with proper authorization,
  // because save_post can be triggered at other times
  if(!isset($_POST['amazonx_noncename']))	// eliminates notices in debug mode
    return $post_id;
  if ( !wp_verify_nonce( $_POST['amazonx_noncename'], plugin_basename(__FILE__)))
    return $post_id;
  // verify if this is an auto save routine. If it is, our form has not been
  // submitted, so we dont want to do anything
  if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ) 
    return $post_id;
  
  // Check permissions
  if ( 'page' == $_POST['post_type'] ) {
    if ( !current_user_can( 'edit_page', $post_id ) )
      return $post_id;
  } else {
    if ( !current_user_can( 'edit_post', $post_id ) )
      return $post_id;
  }
  // OK, we're authenticated: we need to find and save the data
  $asin = $_POST['amazonx_asin'];
  $rating = $_POST['amazonx_rating'];
  if( ($asin == null) || ($rating == null)) {
    delete_post_meta($post_id, 'amazonx_asin');
    delete_post_meta($post_id, 'amazonx_rating');
  } else {
    update_post_meta($post_id, 'amazonx_asin', $asin);
    update_post_meta($post_id, 'amazonx_rating', $rating);
  }
}

function amazonx_write_metabox($post) {
  // write html for metabox form; use nonce for verification
  wp_nonce_field( plugin_basename(__FILE__), 'amazonx_noncename' );		// adds hidden field
  $postid = $post->ID;
  // check if the values are already set, and if so, we must load them into the boxes
  $asin = get_post_meta($postid, 'amazonx_asin', true);
  $rating = get_post_meta($postid, 'amazonx_rating', true);
  $selected = array("", "", "", "", "", "");
  if($rating != "")
  {
    $index = (int)$rating;
	if($index > 5 || $index < 0)
	  $index = 0;
	$selected[$index] = "selected ";
  }
  else
    $selected[0] = "selected ";
  echo 'ASIN: &nbsp;&nbsp;<input type="text" name="amazonx_asin" value="' . $asin . '" size="20" />';
  echo '<br/><br/>';
  echo 'Rating: <select name="amazonx_rating" style="width: 130px">';
  echo '<option ' . $selected[0] . 'value="0">No Rating</option>';
  echo '<option ' . $selected[5] . 'value="5">5 Stars</option>';
  echo '<option ' . $selected[4] . 'value="4">4 Stars</option>';
  echo '<option ' . $selected[3] . 'value="3">3 Stars</option>';
  echo '<option ' . $selected[2] . 'value="2">2 Stars</option>';
  echo '<option ' . $selected[1] . 'value="1">1 Star</option>';
  echo '</select>';
}

function amazonx_register_metabox() {
  add_meta_box('amazonx_metabox_id', 'Amazon Express', 'amazonx_write_metabox', 'post', 'side');
  add_meta_box('amazonx_metabox_id', 'Amazon Express', 'amazonx_write_metabox', 'page', 'side');
}

function amazonx_register_menu() {
  add_options_page('Amazon Express Options', 'Amazon Express', 'manage_options', 'amazonx', 'amazonx_options');
}

function amazonx_options() {
  if (!current_user_can('manage_options'))  {
    wp_die( __('You do not have sufficient permissions to access this page.') );
  }
  
  include('amazonx-options.php');
}

function amazonx_the_content($content)
{
  global $post;		// grab post data so we can read the metadata
  
  //if(!is_singular()) // is_singular = is_single || is_page || is_attachment
  //  return $content;

  $id = $post->ID;		// this just gets page_id when in the booklist page
  $asin = get_post_meta($id, 'amazonx_asin', true);
  $rating = get_post_meta($id, 'amazonx_rating', true);
  
  if($asin == "")
    return $content;			// do nothing
  
  $star_html = "";
  if((int)get_option('amazonx_belowimg') != 2)
	$star_html = ProductBox::star_html($rating);
	
  $clear = '<div style="clear: both; font-size: 0; height: 15px;"></div>';
	
  return ProductBox::product_box_html($asin, $rating, false) . $content . $star_html . $clear;
}

function amazonx_admin_notice()
{
  if(get_option('amazonx_accesskey') == "" || get_option('amazonx_secretkey') == "")
  {
	echo '<div class="updated"><p>Amazon Express is not yet configured. Click <a href="';
	echo admin_url('options-general.php?page=amazonx');
	echo '">here</a> to access the configuration page.</p></div>';
  }
}

function amazonx_write_table($atts)
{
  ProductTable::write_table($atts);
}

function initialize()
{
  // initialization
  wp_enqueue_style('amazonx', plugins_url('/amazonx.css', __FILE__));
  add_shortcode('amazonx', 'amazonx_write_table');
  // when Wordpress is rendering meta boxes, register metabox
  add_action('admin_menu', 'amazonx_register_metabox');
  add_action('admin_menu', 'amazonx_register_menu');
  // Process and save the data entered in the metabox 
  add_action('save_post', 'amazonx_save_metabox_data');
  // Add cover images to beginning of posts
  add_filter('the_content', 'amazonx_the_content');
  add_action('admin_notices', 'amazonx_admin_notice');
}

initialize();

?>
