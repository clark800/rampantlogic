<?php

require_once('amazonx-box.php');

class ProductTable
{
  private static function generate_grid_listing($posts, $columns)
  {
    if($columns == 0) {
      echo 'Cannot generate a grid with zero items per row!';
      return;
    }
    if(count($posts) == 0)
      return;

    $width = 100.0/$columns;
    echo '<table class="amazonx-grid">';  
    for($row = 0; $row*$columns < count($posts); ++$row) {
      echo '<tr>';
      for($col = 0; $col < $columns; ++$col) {
        echo '<td width="' . $width . '%">';
        $index = $row*$columns + $col;
        if($index < count($posts)) {
          $id = $posts[$index]->ID;
          $asin = get_post_meta($id, 'amazonx_asin', true);
          $rating = get_post_meta($id, 'amazonx_rating', true);
          $link = get_permalink($id);
          $title = get_the_title($id);
          echo '<div class="amazonx-item"><center>';
          echo ProductBox::product_box_html($asin, $rating, true, $link);
          echo '<a href="' . $link . '">';
          echo '<div class="amazonx-title">' . $title . '</div>';
          echo '</a>';
          echo '</center></div>';
        }
        echo '</td>';
      }
      echo '</tr>';
    }
    echo '</table>';
  }
  
  private static function generate_listing($posts, $columns) 
  {
    if($columns > 1) {
      self::generate_grid_listing($posts, $columns);
      return;
    }
  
    foreach($posts as $post) {
      setup_postdata($post); // needed to get the contents
  	$id = $post->ID;
  	$asin = get_post_meta($id, 'amazonx_asin', true);
      $rating = get_post_meta($id, 'amazonx_rating', true);
  	echo '<div class="amazonx-item">';
  	echo ProductBox::product_box_html($asin, $rating, true);
      echo '<h2 class="amazonx-title"><a href="' . get_permalink($id) . '">' . get_the_title($id) . '</a></h2>';
      if((int)get_option('amazonx_belowimg') != 2)	// omit rating stars here if they are under the product image
        echo ProductBox::star_html($rating);
      echo '<br/><div class="amazonx-content">';
      echo get_the_content($id);
      echo '</div></div>';
      echo '<div class="amazonx-clear"></div>';	
    }
  }
  
  private static function filter_posts($posts, $minrating, $maxrating) {
    $filtered_posts = (array)null;
    // load posts to be displayed in this category	  
    foreach($posts as $post) {
      $id = $post->ID;
      $asin = get_post_meta($id, 'amazonx_asin', true);
      $rating = get_post_meta($id, 'amazonx_rating', true);
      if($asin == "")
        continue;
  	if((int)$minrating != 0 && (int)$rating < (int)$minrating)
  	  continue;
  	if((int)$maxrating != 0 && (int)$rating > (int)$maxrating)
  	  continue;
  	if((int)$maxrating != 0 && (int)$rating == 0)
  	  continue;
  	array_push($filtered_posts, $post);
    }
    return $filtered_posts;
  }
  
  private static function rating_cmp($post1, $post2)
  {
    $rating1 = get_post_meta($post1->ID, 'amazonx_rating', true);
    $rating2 = get_post_meta($post2->ID, 'amazonx_rating', true);
    if($rating1 == $rating2)
      return strtotime($post1->post_date) < strtotime($post2->post_date) ? 1 : -1;
    return ($rating1 < $rating2) ? 1 : -1;
  }
  
  private static function sort_by_rating(&$posts)
  {
    usort($posts, "ProductTable::rating_cmp");
  }
  
  private static function get_posts_in_category($category_id) 
  {
    $posts_in_category = (array)null;
    // find all posts in this category and remove results that are in subcategories
    if($category_id > 0) {		// don't list any posts in category 0
      $query = "cat={$category_id}&numberposts=-1&post_type=any&orderby=date&order=DESC";
      $posts = get_posts($query);
      foreach($posts as $post) {
        $categories = get_the_category($post->ID);
  	  foreach($categories as $category)
          if($category->cat_ID == $category_id)
  		  array_push($posts_in_category, $post);
      }
    }
    return $posts_in_category;
  }
  
  private static function grouped_table($category_id, $options)
  {
    extract($options);
    $posts_in_category = self::get_posts_in_category($category_id);	
  
    $display_posts = self::filter_posts($posts_in_category, $minrating, $maxrating); 
    
    // print the category title if there are posts to display
    if((int)$show_categories != 0 && count($display_posts) > 0) {
      echo '<div class="amazonx-category">' . get_cat_name($category_id) . '</div>';	
    }
  
    if($sort_by_rating != 0) 
      self::sort_by_rating($display_posts);
  
    if($limit > 0) 
        $display_posts = array_slice($display_posts, 0, $limit);
   
    self::generate_listing($display_posts, $columns); 
    
    // now run through subcategories 
    $subcategories = get_categories("parent={$category_id}&hide_empty=0");
    foreach($subcategories as $subcategory)
      self::grouped_table($subcategory->cat_ID, $options);
  }
  
  private static function ungrouped_table($category_id, $options) {
    extract($options);
    $query = "cat={$category_id}&numberposts=-1&post_type=any&orderby=date&order=DESC";
    $posts = get_posts($query);
    $display_posts = self::filter_posts($posts, $minrating, $maxrating);
    if($sort_by_rating != 0)
      self::sort_by_rating($display_posts);
    if($limit > 0)
      $display_posts = array_slice($display_posts, 0, $limit);
    self::generate_listing($display_posts, $columns); 
  }
  
  public static function write_table($atts) {
    $options = shortcode_atts(array(
  	    'category' => 0,		// 0 is the root category
        'minrating' => 0,
        'maxrating' => 0,
  	    'show_categories' => 1,
        'group_by_category' => 1,
        'sort_by_rating' => 0,
        'columns' => 1,
        'limit' => -1
    ), $atts);
   
    if($options['group_by_category'] != 0) 
      self::grouped_table($options['category'], $options);
    else
      self::ungrouped_table($options['category'], $options);
  }
}
  
?>
