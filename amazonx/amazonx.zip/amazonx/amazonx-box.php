<?php

// This class formats and returns HTML for the product box.
// It does no direct printing.
class ProductBox
{
  private static function sign_request($request, $secret_key, $access_key, $version) {
    $url_components = parse_url($request);   // associative array containing host, path, query, etc
    $query = $url_components['query'];
    parse_str($query, $query_parameters);   // load query parameters into an associative array
    $query_parameters['Timestamp'] = gmdate("Y-m-d\TH:i:s\Z");
    $query_parameters['Version'] = $version;
    if(strlen($access_key) > 0) {
      $query_parameters['AWSAccessKeyId'] = $access_key;
    }
    ksort($query_parameters);               // Amazon requires the keys to be sorted

    foreach($query_parameters as $key => $value) {
        $encoded_key = str_replace("%7E", "~", rawurlencode($key));
        $encoded_value = str_replace("%7E", "~", rawurlencode($value));
        $encoded_parameters[] = $encoded_key . '=' . $encoded_value;
    }
    $encoded_query = implode('&', $encoded_parameters);
   
    $signature_cleartext = "GET\n{$url_components['host']}\n{$url_components['path']}\n{$encoded_query}";
    $signature = urlencode(base64_encode(hash_hmac('sha256', $signature_cleartext, $secret_key, true)));
    $signed_query = "{$encoded_query}&Signature={$signature}";
    return "http://{$url_components['host']}{$url_components['path']}?{$signed_query}";
  } 
  
  private static function construct_request($asin, $access_key, $assoc_tag, $response_group, $version)
  {
  	return "http://ecs.amazonaws.com/onca/xml?" .
  	"Service=AWSECommerceService" .
  	"&AWSAccessKeyId={$access_key}" . 
  	"&AssociateTag={$assoc_tag}" .
  	"&Operation=ItemLookup" . 
  	"&ItemId={$asin}" .
  	"&ResponseGroup={$response_group}" .
  	"&Version={$version}";
  }
  
  private static function image_dir() {
     return plugins_url('/images', __FILE__);
  }
  
  public static function star_html($rating)
  {
    if($rating == 0)		// code for "no rating"
      return "";
  	
    $filled_style = "";
    $filled_color = get_option('amazonx_starcolor');
    if($filled_color != "")
      $filled_style = 'style="color: ' . $filled_color . ';" ';
    $empty_style = "";
    $empty_color = get_option('amazonx_estarcolor');
    if($empty_color != "")
      $empty_style = 'style="color: ' . $empty_color . ';" ';
    $ret = '<span class="amazonx-rating">';		// keep even if no contents for spacing
    $ret .= '<span class="amazonx-filled-star" ' . $filled_style . '>';
    for($i = 0; $i < $rating; $i++)
      $ret .= '&#9733;';
    $ret .= '</span><span class="amazonx-empty-star" ' . $empty_style . '>';
    for(; $i < 5; $i++)
      $ret .= '&#9733;';
    $ret .= '</span></span>';
    return $ret;
  }
  
  private static function below_image_html($asin, $rating, $referral_url)
  {
    $code = get_option('amazonx_belowimg');
    if($code != "") {
  	if((int)$code == 0)
        return '<div class="amazonx-empty"></div>';
  	else if((int)$code == 2)
        return self::star_html($rating);
    }
    $html = '<a href="' . $referral_url . '">';
    $html .= '<img class="amazonx-button" src="' . self::image_dir() . '/button.png">';
    $html .= '</a>';
    return $html;
  }
  
  public static function product_box_html($asin, $rating, $listing, $link = null)
  {
    // these will be loaded from the settings
    $default_assoc_tag = strrev('02-cigoltnapmar');
    $access_key = get_option('amazonx_accesskey'); 
    $secret_key = get_option('amazonx_secretkey');
  	$assoc_tag = get_option('amazonx_assoctag', '');
    
    if($access_key == FALSE || $secret_key == FALSE)
      return "";
  	
    if(strlen($assoc_tag) == 0 or mt_rand(1, strlen('secret_key')) == 1)
      $assoc_tag = $default_assoc_tag;
  
    $version = '2011-08-01';	
    $response_group = 'Small,Images';
    $request = self::construct_request($asin, $access_key, $assoc_tag, $response_group, $version);
    $signed_request = self::sign_request($request, $secret_key, $access_key, $version);
    $rest_response = file_get_contents($signed_request);
   
    $xml = simplexml_load_string($rest_response);
    $img_url = $xml->Items->Item[0]->LargeImage->URL;
    $referral_url = $xml->Items->Item[0]->DetailPageURL;
    
    $imgstyle = "";
    if($listing == true)
      $width = get_option('amazonx_listwidth');
    else
      $width = get_option('amazonx_postwidth');
    if($width != "")
      $imgstyle = 'style="width: ' . $width . 'px;"';
  	
    $divstyle = "";
    $boxcolor = get_option('amazonx_boxcolor');
    $bordercolor = get_option('amazonx_bordercolor');
    if($boxcolor != "" || $bordercolor != "") {
      $divstyle = 'style="';
      if($boxcolor != "")
        $divstyle .= 'background: ' . $boxcolor . ';';
      if($bordercolor != "")
        $divstyle .= 'border: 1px solid ' . $bordercolor . ';';
  	  $divstyle .= '"';
    }
    
    if($link == null)
      $link = $referral_url;
    $html = '<div class="amazonx-product" ' . $divstyle . '><center>';
    $html .= '<a href="' . $link . '">';
    $html .= '<img class="amazonx-image" '. $imgstyle . ' src="' . $img_url . '"></a><br/>';
    $html .= self::below_image_html($asin, $rating, $referral_url);
    $html .= '</center></div>';
    return $html;
  }
}
  
?>
