To install, copy this folder to /wp-content/plugins/ on your Wordpress server.

Geopost is copyright Rampant Logic 2010. 
http://www.rampantlogic.com